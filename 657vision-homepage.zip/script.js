// Небольшое появление элементов при загрузке страницы
document.documentElement.classList.add('js-ready');
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.hero-logo, .hero-copy, .social-button').forEach((item, index) => {
    item.animate(
      [
        { opacity: 0, transform: 'translateY(16px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ],
      { duration: 650, delay: index * 100, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'both' }
    );
  });
});
